import numpy as np, json, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R=json.load(open('results.json'))
th=np.linspace(-90,90,3601)
def af(N,th,t0=0):
    psi=np.pi*(np.sin(np.radians(th))-np.sin(np.radians(t0)));den=N*np.sin(psi/2)
    with np.errstate(all='ignore'): return np.abs(np.where(abs(den)<1e-9,1,np.sin(N*psi/2)/den))
fig,ax=plt.subplots(figsize=(6.2,3.2),dpi=200)
for N,c in zip((2,4,8,16),('#999','#d95f02','#1b9e77','#1f3864')):
    ax.plot(th,20*np.log10(np.maximum(af(N,th),1e-3)),label=f'N={N}',color=c,lw=1.2)
ax.axhline(-10,ls='--',color='k',lw=.8);ax.text(-88,-9,'−10 dB (SIR threshold)',fontsize=7)
ax.set_ylim(-40,2);ax.set_xlim(-90,90);ax.set_xlabel('angle from broadside (deg), beam steered to 0°');ax.set_ylabel('|AF| (dB)');ax.legend(fontsize=7,ncol=4,loc='lower center');ax.grid(alpha=.3);ax.set_title('ULA array factor, d = λ/2',fontsize=9)
plt.tight_layout();plt.savefig('fig_q5.png')
q=R['q7'];M=[r['M'] for r in q]
fig,ax=plt.subplots(1,2,figsize=(6.4,2.9),dpi=200)
ax[0].plot(M,[100*r['orig_util'] for r in q],'o-',color='#d95f02',label='Original (dedicated)');ax[0].plot(M,[100*r['new_util'] for r in q],'s-',color='#1f3864',label='Redesign (on-demand)')
ax[0].set_xlabel('sources M');ax[0].set_ylabel('slot utilisation (%)');ax[0].legend(fontsize=7);ax[0].grid(alpha=.3)
ax[1].plot(M,[100*r['orig_loss'] for r in q],'o-',color='#d95f02');ax[1].plot(M,[100*r['new_loss'] for r in q],'s-',color='#1f3864')
ax[1].set_xlabel('sources M');ax[1].set_ylabel('bursts lost (%)');ax[1].grid(alpha=.3)
plt.tight_layout();plt.savefig('fig_q7.png')
