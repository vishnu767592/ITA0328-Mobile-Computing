import numpy as np, json, csv, math
R={}
def wr(name,rows,hdr):
    with open(name,'w',newline='') as f:
        w=csv.writer(f);w.writerow(hdr);w.writerows(rows)
# ---------- Q1
def q1():
    rng=np.random.default_rng(1); T=2000; out=[]
    for a in (0.9,0.6,0.3):
        # 2-state Markov link, mean up-burst 10 slots; stationary availability a
        p_ud=0.1; p_du=p_ud*a/(1-a)
        s=1; link=[]
        for t in range(T):
            link.append(s)
            s = (0 if rng.random()<p_ud else 1) if s else (1 if rng.random()<p_du else 0)
        link=np.array(link)
        gen=np.arange(0,T,2)  # reading every 2 slots -> 1000 readings
        # strategy 1: send immediately
        d1=int(link[gen].sum()); l1=len(gen)-d1
        # strategy 2: store & forward, 5 updates/slot when link up, queue unbounded; run extra 3000 slots drain
        q=[];dl=[];ext=np.concatenate([link,np.ones(3000,int)*0])  # no link after T => leftovers undelivered
        g=set(gen.tolist())
        for t in range(T):
            if t in g:q.append(t)
            if link[t]:
                for _ in range(5):
                    if q: dl.append(t-q.pop(0))
        delayed=sum(1 for x in dl if x>0); notdel=len(q)
        out.append(dict(avail=a,measured=round(float(link.mean()),3),n=len(gen),imm_deliv=d1,imm_lost=l1,imm_delayed=0,imm_delay=0.0,
            sf_deliv_now=len(dl)-delayed,sf_delayed=delayed,sf_lost=notdel,sf_delay=round(float(np.mean(dl)),1)))
    wr('q1.csv',[list(o.values()) for o in out],list(out[0].keys())); return out
R['q1']=q1()
# ---------- Q2
def q2():
    rng=np.random.default_rng(2)
    # usable channels
    fd=dict(nominal=80,guard=2,ctrl=2,traffic=76,eff=0.95)
    td=dict(nominal=80,carriers=9,slots=72,ctrl=1,traffic=71,eff=114/156.25)  # GSM burst: 114 data bits of 156.25
    res=[]
    def run(name,lam,hold,duty,mix,sync=False,T=3600):
        out={}
        for sch,d,setup in (('FDMA',fd,0.15),('TDMA',td,0.03)):
            C=d['traffic'];
            # arrivals
            if sync:
                arr=np.concatenate([np.full(100,k*20.0) for k in range(int(T/20))])
            else:
                arr=np.cumsum(rng.exponential(1/lam,int(lam*T*1.5)));arr=arr[arr<T]
            busy=[];used=0.0;held=0.0;blk=0;tot=0
            for t in arr:
                tot+=1
                busy=[b for b in busy if b>t]
                if len(busy)>=C: blk+=1;continue
                h=hold if sync else rng.exponential(hold)
                isdata=rng.random()>mix[0]
                dc=duty[1] if isdata else duty[0]
                hold_eff=h+setup
                busy.append(t+hold_eff)
                held+=hold_eff; used+=h*dc*d['eff']
            cap=C*T
            out[sch]=dict(calls=tot,blocked=blk,block=round(blk/tot,4),util=round(used/cap,4),wasted=round(1-used/cap,4),heldutil=round(held/cap,4))
        return out
    sets=[('D1 continuous voice, 70 E',70/120,120,(1,1),(1.0,),False),
          ('D2 bursty data 10% duty, 70 E',70/120,120,(1,0.1),(0.0,),False),
          ('D3 70/30 voice-data mix, 70 E',70/120,120,(1,0.1),(0.7,),False),
          ('D4 edge: synchronised 100-call bursts, 3 s calls',None,3,(1,1),(1.0,),True)]
    rows=[]
    for n,lam,h,duty,mix,sy in sets:
        o=run(n,lam,h,duty,mix,sy); res.append((n,o))
        for s in o: rows.append([n,s]+list(o[s].values()))
    wr('q2.csv',rows,['dataset','scheme','calls','blocked','blocking','utilisation','wasted','held_util'])
    return dict(fd=fd,td=td,res=res)
R['q2']=q2()
# ---------- Q3
def walsh(n):
    H=np.array([[1]]);
    while H.shape[0]<n: H=np.block([[H,H],[H,-H]])
    return H
def cdma(L,K,cond,nb=100000,ebn0_db=10,seed=3):
    rng=np.random.default_rng(seed+L*7+K)
    A=np.ones(K)
    if 'power' in cond: A[1:]=np.sqrt(10)   # interferers at 10x power; victim (user 0) at 1x
    bits=rng.choice([-1,1],(K,nb))
    chips=np.zeros((nb,L))
    if cond=='random':   # long-code model: fresh random code every bit
        c0=rng.choice(np.array([-1,1],dtype=np.int8),(nb,L)); chips+=A[0]*bits[0][:,None]*c0
        cc=[];sq=[]
        for k in range(1,K):
            ck=rng.choice(np.array([-1,1],dtype=np.int8),(nb,L)); chips+=A[k]*bits[k][:,None]*ck
            x=(c0*ck).sum(1); sq.append(np.mean(x.astype(float)**2)); cc.append(np.abs(x).max())
        corr_rms=float(np.sqrt(np.mean(sq))) if sq else 0
    else:
        C=walsh(L)[:K]; c0=np.tile(C[0],(nb,1))
        for k in range(K):
            s=(bits[k][:,None]*C[k][None,:]*A[k]).ravel()
            if 'async' in cond and k>0: s=np.roll(s,int(rng.integers(1,L)))
            chips+=s.reshape(nb,L)
        cc=[abs(C[0]@C[j]) for j in range(1,K)]
        corr_rms=0.0
    sig2=L/(2*10**(ebn0_db/10))
    chips=chips+rng.normal(0,math.sqrt(sig2),chips.shape)
    r=(chips*c0).sum(1)/L
    err=int(np.sum(np.sign(r)!=bits[0]))
    return err,nb,(max(cc) if cc else 0),round(corr_rms,1)
def q3():
    rows=[]
    for L in (8,16,64):
        for cond in ('walsh','random','power','async','power_async'):
            for K in sorted({2,L//4,L//2,L}):
                if K<2:continue
                e,nb,mx,mn=cdma(L,K,cond)
                rows.append([L,cond,K,e,nb,e/nb,mx,round(mn,1),L,round(10*math.log10(L),1)])
    wr('q3.csv',rows,['L','cond','K','errors','bits','BER','max_|xcorr|','rms_xcorr(random)','PG','PG_dB']); 
    # users supported at L=64, BER<=1e-3
    sup={}
    for cond in ('random','async','power_async','walsh'):
        best=0
        for K in range(2,65,2):
            e,nb,_,_=cdma(64,K,cond); 
            if e/nb<=1e-3:best=K
            else: 
                if cond!='walsh':break
        sup[cond]=best
    return dict(rows=rows,sup=sup)
R['q3']=q3()
# ---------- Q4
def q4():
    N=64;U=8;P=1000
    # orthogonality
    n=np.arange(64*4)/(64*4); ip={}
    for a,b in ((1,2),(1,3),(2,3),(5,5),(5,6)):
        x=np.exp(2j*np.pi*a*n);y=np.exp(2j*np.pi*b*n);ip[(a,b)]=abs(np.vdot(y,x))/len(n)
    # with half-symbol misalignment (no CP): spacing mismatch -> not orthogonal fractional freq offset 0.5
    x=np.exp(2j*np.pi*1*n);y=np.exp(2j*np.pi*2.5*n);ipoff=abs(np.vdot(y,x))/len(n)
    rng=np.random.default_rng(4)
    snr_db=np.array([22,19,16,13,10,7,4,1]);snr=10**(snr_db/10)
    def gains(rng,U,snr):
        taps=6;pdp=np.exp(-np.arange(taps)/2.0);pdp/=pdp.sum()
        h=(rng.normal(size=(U,taps))+1j*rng.normal(size=(U,taps)))/np.sqrt(2)*np.sqrt(pdp)
        H=np.fft.fft(h,N,axis=1); return snr[:,None]*np.abs(H)**2
    schemes=['contiguous','interleaved','best-subcarrier','max-min greedy','min-rate + best']
    tot={s:np.zeros(U) for s in schemes};jn={s:[] for s in schemes};sumr={s:[] for s in schemes};outage={s:np.zeros(U) for s in schemes}
    Rmin=8.0 # bits per OFDM symbol = 2 Mbps at 250k sym/s
    for _ in range(P):
        g=gains(rng,U,snr);r=np.log2(1+g)
        rate={}
        rate['contiguous']=np.array([r[u,u*8:(u+1)*8].sum() for u in range(U)])
        rate['interleaved']=np.array([r[u,u::U].sum() for u in range(U)])
        b=r.argmax(0);rate['best-subcarrier']=np.array([r[u,b==u].sum() for u in range(U)])
        acc=np.zeros(U);free=set(range(N))
        while free:
            u=acc.argmin();k=max(free,key=lambda k:r[u,k]);acc[u]+=r[u,k];free.remove(k)
        rate['max-min greedy']=acc
        acc=np.zeros(U);free=set(range(N))
        while True:
            below=[u for u in range(U) if acc[u]<Rmin]
            if not below or not free:break
            u=min(below,key=lambda u:acc[u]);k=max(free,key=lambda k:r[u,k]);acc[u]+=r[u,k];free.remove(k)
        for k in free:
            u=r[:,k].argmax();acc[u]+=r[u,k]
        rate['min-rate + best']=acc
        for s in schemes:
            x=rate[s];tot[s]+=x;sumr[s].append(x.sum());jn[s].append(x.sum()**2/(U*np.sum(x**2)));outage[s]+=(x<Rmin)
    out={s:dict(sum=float(np.mean(sumr[s])),per=(tot[s]/P).round(1).tolist(),jain=float(np.mean(jn[s])),out=(outage[s]/P).round(3).tolist()) for s in schemes}
    # multiuser diversity
    md=[]
    for K in (1,2,4,8,16,32):
        rng2=np.random.default_rng(5);rr=[];bb=[]
        for _ in range(500):
            g=gains(rng2,K,np.full(K,10.0));r=np.log2(1+g)
            bb.append(r.max(0).sum())
            rr.append(sum(r[(k%K),k] for k in range(N)))
        md.append((K,np.mean(rr),np.mean(bb),np.mean(bb)/np.mean(rr)))
    wr('q4.csv',[[s,out[s]['sum'],out[s]['jain']]+out[s]['per'] for s in schemes],['scheme','sum_bits_per_sym','jain']+[f'u{i+1}' for i in range(U)])
    return dict(ip={str(k):v for k,v in ip.items()},ipoff=ipoff,out=out,md=md,Rmin=Rmin)
R['q4']=q4()
# ---------- Q5
def af(N,th,th0,d=0.5):
    psi=2*np.pi*d*(np.sin(np.radians(th))-np.sin(np.radians(th0)))
    num=np.sin(N*psi/2);den=N*np.sin(psi/2)
    with np.errstate(all='ignore'):
        a=np.where(np.abs(den)<1e-9,1.0,num/den)
    return np.abs(a)
def q5():
    th=np.linspace(-90,90,36001);out={};thr=10
    for N in (2,4,8,16):
        a=af(N,th,0.0);db=20*np.log10(np.maximum(a,1e-9))
        c=np.argmin(abs(th));
        # HPBW
        hp=th[(a>=1/np.sqrt(2))];hpbw=hp.max()-hp.min()
        # first null
        r=a[c:];i=np.where(r<1e-3)[0][0];fn=th[c+i]
        # sidelobe level: max beyond first null
        sll=db[c+i:].max() if N>2 else None
        # sidelobe from both sides of the pattern
        sir={s:round(float(-20*np.log10(max(af(N,s,0.0),1e-9))),1) for s in (5,10,15,20,30,45,60)}
        ds=np.arange(0.5,60.01,0.1);sirs=-20*np.log10(np.maximum(af(N,ds,0.0),1e-9))
        bad=np.where(sirs<thr)[0];minsep=ds[bad.max()+1] if len(bad) else ds[0]
        # steered at 45 deg
        sirs45=-20*np.log10(np.maximum(af(N,45+ds,45.0),1e-9)); 
        bad2=np.where(sirs45[ds<40]<thr)[0];minsep45=ds[bad2.max()+1] if len(bad2) else ds[0]
        # angular spread jitter 3deg on both users
        rng=np.random.default_rng(6);jit={}
        for s in (5,10,20,30):
            tA=rng.normal(0,3,20000);tB=s+rng.normal(0,3,20000)
            sig=af(N,tA,0.0)**2;itf=af(N,tB,0.0)**2
            jit[s]=round(float(10*np.log10(sig.mean()/itf.mean())),1)
        out[N]=dict(hpbw=round(float(hpbw),1),fnbw=round(float(2*fn),1),sll=None if sll is None else round(float(sll),1),sir=sir,minsep=round(float(minsep),1),minsep45=round(float(minsep45),1),jit=jit)
    rows=[[N,v['hpbw'],v['fnbw'],v['sll'],v['minsep'],v['minsep45']]+[v['sir'][s] for s in (5,10,15,20,30,45,60)] for N,v in out.items()]
    wr('q5.csv',rows,['N','HPBW','FNBW','SLL_dB','minsep_10dB','minsep_45deg']+[f'SIR@{s}' for s in (5,10,15,20,30,45,60)])
    return out
R['q5']=q5()
# ---------- Q6
def q6():
    crit=['C1 Capacity/reuse','C2 Bursty & many users','C3 Interference/jam robustness','C4 Low complexity (sync, power ctrl)','C5 Fading adaptability/peak rate']
    techs=['SDMA','TDMA','FDMA','CDMA','OFDMA']
    base=np.array([[5,3,2,2,3],[3,2,2,3,2],[3,1,2,5,1],[4,4,5,1,3],[4,3,3,3,5]])
    deps={'Cellular voice':[0.35,0.10,0.25,0.20,0.10],'Tactical link':[0.10,0.10,0.45,0.15,0.20],'Stadium downlink':[0.30,0.10,0.10,0.10,0.40],'5000 sensors':[0.10,0.40,0.15,0.30,0.05]}
    ov={'Tactical link':{(0,2):4,(1,2):1,(2,2):1},'Stadium downlink':{(0,1):2,(3,0):3,(3,4):2},'5000 sensors':{(0,0):1,(4,4):2,(2,0):2,(1,0):2,(1,1):1,(4,2):2,(4,1):2},'Cellular voice':{(0,0):4,(1,3):4,(1,2):3,(4,0):4,(4,1):2}}
    out={}
    for d,w in deps.items():
        M=base.copy().astype(float)
        for (t,c),v in ov[d].items():M[t,c]=v
        w=np.array(w);sc=M@w;rk=np.argsort(-sc)
        flips=[];base_win=techs[rk[0]]
        for c in range(5):
            for f in (0.8,1.2):
                w2=w.copy();w2[c]*=f;w2/=w2.sum();s2=M@w2;win=techs[int(s2.argmax())]
                if win!=base_win:flips.append((crit[c][:2],f,win))
        out[d]=dict(M=M.astype(int).tolist(),w=w.tolist(),sc=sc.round(2).tolist(),win=base_win,second=techs[rk[1]],margin=round(float(sc[rk[0]]-sc[rk[1]]),2),flips=flips)
    wr('q6.csv',[[d]+v['sc'] for d,v in out.items()],['deployment']+techs)
    return dict(crit=crit,techs=techs,out=out)
R['q6']=q6()
# ---------- Q7
def q7():
    C=71;Cd=66;T=20000;Lm=20;duty=0.1;pb=duty/(Lm*(1-duty)) # burst arrival prob per idle slot
    rows=[];res=[]
    for M in (50,71,100,200,400,500,600,650,700,800):
        rng=np.random.default_rng(7)
        # ORIGINAL: first C sources own a slot; others blocked at admission
        adm=min(M,C);served_o=0;bursts_o=0;lost_o=0
        busy_until=np.zeros(M,int)
        for t in range(T):
            idle=busy_until<=t
            new=idle&(rng.random(M)<pb);ids=np.where(new)[0]
            for i in ids:
                L=max(1,int(rng.geometric(1/Lm)));bursts_o+=1
                if i<adm: busy_until[i]=t+L;served_o+=L
                else: lost_o+=1;busy_until[i]=t+L  # blocked source still 'wants' to send
        # REDESIGN: reservation-based dynamic allocation
        rng=np.random.default_rng(7);busy_until=np.zeros(M,int);servers=[]; # end times
        queue=[];bursts=0;lost=0;served=0;msgs=0;wait=[];used_slots=0
        for t in range(T):
            servers=[e for e in servers if e>t]
            idle=busy_until<=t
            new=idle&(rng.random(M)<pb)
            for i in np.where(new)[0]:
                L=max(1,int(rng.geometric(1/Lm)));bursts+=1;msgs+=1  # request
                queue.append([t,L,i]);busy_until[i]=10**9
            nq=[]
            for q in queue:
                if t-q[0]>20: lost+=1;busy_until[q[2]]=t;continue # request timed out
                if len(servers)<Cd:
                    servers.append(t+q[1]);wait.append(t-q[0]);msgs+=2;served+=q[1] # grant + release
                    busy_until[q[2]]=t+q[1]
                else: nq.append(q)
            queue=nq
        row=dict(M=M,orig_adm=adm,orig_loss=round(lost_o/bursts_o,3),orig_util=round(served_o/(C*T),3),orig_msgs=2*adm,
                 new_loss=round(lost/bursts,3),new_util=round(served/(C*T),3),new_msgs=msgs,new_delay=round(float(np.mean(wait)),2) if wait else 0,msgs_per_burst=round(msgs/bursts,2))
        res.append(row)
    wr('q7.csv',[list(r.values()) for r in res],list(res[0].keys())); return res
R['q7']=q7()
json.dump(R,open('results.json','w'),default=lambda o:o.tolist() if hasattr(o,'tolist') else str(o),indent=1)
